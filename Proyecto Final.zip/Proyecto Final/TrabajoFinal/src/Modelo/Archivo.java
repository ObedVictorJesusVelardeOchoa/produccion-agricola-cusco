package Modelo;

import java.io.FileInputStream;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author danie
 */
//Creamos la clase archivo con los atributos ruta y flujo entrada
public class Archivo {

    private String ruta;   //La direccion del archivo que vamos a leer
    private FileInputStream flujoEntrada;         //Creamos la variable de nombre flujoEntrada que será de tipo FileInputStream

    //Constructor con el que podremos acceder a los atributos de la clase Archivo y podremos asignarle valores
    //Para usarlo, tendremos que pasarle los parametros ruta y flujoEntrada
    public Archivo(String ruta) {
        this.ruta = ruta;
    }

    //Getters y Setters
    public FileInputStream getFlujoEntrada() {
        return flujoEntrada;
    }

    public void setFlujoEntrada(FileInputStream flujoEntrada) {
        this.flujoEntrada = flujoEntrada;
    }

    //Con este metodo, cuando lo invoquemos, "instanciaremos"(nombre de crear un objeto a partir de una clase)
    //la clase FileInputStream, la cual es una clase de java. Al ser una clase, tambien tendra sus atributos
    //Estos atributos nos permiten manipular un archivo, para esto debemos pasarle la ruta del archivo
    //Si en el proceso, no se encuentra el archivo nos mostrará el tipo de error para ese caso.
    public void abrirArchivo() {
        try {
            flujoEntrada = new FileInputStream(ruta);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void cerrarArchivo() {
        try {
            flujoEntrada.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

}
