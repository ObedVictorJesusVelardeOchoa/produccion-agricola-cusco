/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author danie
 */
public class Resultado {

    int numeroEjercicio;
    String titulo;
    String mensaje;

    public Resultado(int numeroEjercicio, String titulo, String mensaje) {
        this.numeroEjercicio = numeroEjercicio;
        this.titulo = titulo;
        this.mensaje = mensaje;
    }

    public int getNumeroEjercicio() {
        return numeroEjercicio;
    }

    public void setNumeroEjercicio(int numeroEjercicio) {
        this.numeroEjercicio = numeroEjercicio;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    @Override
    public String toString() {
        DateTimeFormatter format = DateTimeFormatter.ofPattern("HH:mm:ss");  //Declaramos el formato de la hora
        String fecha = LocalDate.now().toString();  //obtenemos la fecha actual
        String hora = format.format(LocalTime.now());   //Obenemos la hora con el formato previamente declarado
        return "Fecha: " + fecha + " Hora: " + hora
                + //Retornamos la fecha, la hora, el numero de ej., el titulo
                " | Ejercicio N° " + getNumeroEjercicio()
                + // y el mensaje que vamos a mostrar  
                " | Titulo: " + getTitulo()
                + //Todo dentro de este ToString se mostrara en el archivo 
                " | Resultados: " + getMensaje();
    }

}
