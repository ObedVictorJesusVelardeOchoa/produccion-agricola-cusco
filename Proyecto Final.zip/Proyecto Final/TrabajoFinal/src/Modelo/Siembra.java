/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author danie
 */
//Creamos la clase siembra que contendra estos atributos
public class Siembra {

    private String provincia;
    private String distrito;
    private double total;

    public Siembra(String provincia, String distrito, double total) {
        this.provincia = provincia;
        this.distrito = distrito;
        this.total = total;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getDistrito() {
        return distrito;
    }

    public void setDistrito(String distrito) {
        this.distrito = distrito;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    @Override
    public String toString() {
        return "Total de siembra en " + getDistrito() + ", " + getProvincia() + ": " + getTotal();
    }

}
