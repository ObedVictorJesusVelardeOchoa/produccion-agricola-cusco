/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author danie
 */
public class TiposCultivo {

    private String ano;
    private String[] cultivos;
    private Double[] cantidadSembrada;

    public TiposCultivo(String ano, String[] cultivos, Double[] cantidadSembrada) {
        this.ano = ano;
        this.cultivos = cultivos;
        this.cantidadSembrada = cantidadSembrada;
    }

    public String getAno() {
        return ano;
    }

    public void setAno(String ano) {
        this.ano = ano;
    }

    public String[] getCultivos() {
        return cultivos;
    }

    public void setCultivos(String[] cultivos) {
        this.cultivos = cultivos;
    }

    public Double[] getCantidadSembrada() {
        return cantidadSembrada;
    }

    public void setCantidadSembrada(Double[] cantidadSembrada) {
        this.cantidadSembrada = cantidadSembrada;
    }

    @Override
    public String toString() {
        String mensaje = "";
        for (int i = 0; i < getCultivos().length; i++) {
            mensaje += "\nEl cultivo " + getCultivos()[i] + " en el año " + getAno() + " es de: " + getCantidadSembrada()[i];
        }
        return mensaje;
    }

}
