/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Archivo;
import Modelo.Errores;
import Modelo.Resultado;
import Modelo.Siembra;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author danie
 */
public class controladorSiembra {

    private Archivo archivo;
    private FileInputStream flujoEntrada;

    public controladorSiembra(Archivo archivo) {
        this.archivo = archivo;
    }

    public void ConsultarSiembrasTotalesProvinciaDistrito(String provincia, String distrito) throws Exception {
        try {
            Scanner scan = new Scanner(System.in);
            /* Obtenemos el FileInputStrem ya abierto */
            flujoEntrada = archivo.getFlujoEntrada();

            //Una vez tengamos el archivo listo para manipular, leemos todos sus bytes y guardamos los bytes 
            //En un arreglo de bytes
            byte[] data = flujoEntrada.readAllBytes();

            //Una vez contenidos los bytes en un arreglo, con new String los "traducimos" a String para que puedan ser
            //leíbles(como se ve en el txt) y los asignamos todos a una sola variable de texto "contenido"
            String contenido = new String(data, StandardCharsets.UTF_8);

            //En esa variable, todos los registros estaran uno sobre otro, con "split" hacemos que tome esos
            //saltos de linea como separadores para guardarlos cada uno en un indice del arreglo de Strings lineasregistro
            String[] lineasRegistro = contenido.split("\n");

            //Una vez los tengamos, necesitaremos sacar del arreglo la primera línea, es decir el primer indice del arreglo
            //que tiene DEPARTAMENTO, PROVINCIA, DISTRITO, etc... y solo dejar los registros que nos importan, como 
            //Antahuasi, Cuzco, 2018, etc... el "copyofRange" copiará los registros desde el indice uno hasta el ultimo para 
            //transformar ese viejo arreglo con la primera linea que no nos sirve en uno que solo tenga los registros que
            //nos interesan analizar. Al final se modificará el arreglo sin la primera posicion.
            lineasRegistro = Arrays.copyOfRange(lineasRegistro, 1, lineasRegistro.length);

            //La variable total siembra al final tendra la suma de todas las siembras dada una provincia y un 
            //distrito. Esta variable se va a ir acumulando para conseguir este valor final.
            int totalSiembra = 0;

            //El for each recorre un arreglo linea por linea, y en cada linea la toma como si fuera un arreglo.
            //Este va a realizar las indicaciones que dicen dentro de los corchetes para cada linea individualmente
            //Cuando pase, por ejemplo, la primera linea, con el "if" va a validar que la provincia y el distrito
            //que se brindo cuando se invoco al metodo consultarSiembrasTotalesProvinciaDistrito sean iguales
            //a los indices 1 y 2 del arreglo. Si lo son, se igualara a una cadena para luego convertirla en entero
            //con convertircadenatonumero(un metodo personalizado que nosotros creamos) para luego acumularla en la
            //variable totalSiembra. En cada recorrido se ira acumulando el indice 7, previamente convertido a entero,
            //hasta conseguir el valor total de la siembra. Nota: El archivo csv estara compuesto de cadenas de texto
            //no numeros. 
            for (String linea : lineasRegistro) {
                String[] campos = linea.split(";");

                String compoProvincia = campos[1];
                String campoDistrito = campos[2];

                if (provincia.equalsIgnoreCase(compoProvincia) && distrito.equalsIgnoreCase(campoDistrito)) {
                    String siembra = campos[7];
                    totalSiembra += Conversiones.ConvertirCadenaToEntero(siembra);
                }
            }

            //Si el total de siembra al final es mayor que cero, entonces nos mostrara la informacion que nos interesa
            //saber. Sino, mostrara el mensaje de que no se encontro informacion en el archivo.
            if (totalSiembra > 0) {
                Siembra s = new Siembra(provincia.toUpperCase(), distrito.toUpperCase(), totalSiembra);
                System.out.println("\n===============RESULTADO==================");
                System.out.printf("%-15s %-15s %-15s\n", "PROVINCIA", "DISTRITO", "TOTAL SIEMBRA");
                System.out.println("------------------------------------------------");
                System.out.printf("%-15s %-15s %-15f\n", s.getProvincia(), s.getDistrito(), s.getTotal());
                System.out.println("Le gustaria guardar los resultados en un archivo txt? (S/N) :");
                String opcion = scan.nextLine();
                boolean validacion = true;
                while (validacion == true) {
                    if (opcion.toUpperCase().equals("S")) {
                        Resultado result = new Resultado(1, "Siembras por provincia y distrito", "" + s.toString());
                        controladorResultado.guardarResultado(result);
                        System.out.println("Datos guardados correctamente en un txt.");
                        validacion = false;

                    } else if (opcion.toUpperCase().equals("N")) {
                        validacion = false;
                    } else {
                        System.out.println("Opcion ingresada no permitida. ");
                        validacion = true;
                    }

                }

            } else {
                System.out.println("No se encontro informacion correspondiente a la Provincia: " + provincia.toUpperCase() + " Distrito: " + distrito.toUpperCase());
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Errores error = new Errores(e.getMessage(), "Error",
                    LocalDate.now().toString(), LocalTime.now().toString(), "Usuario");
            controladorErrores.guardarError(error);
            throw e;
        }
    }

}
