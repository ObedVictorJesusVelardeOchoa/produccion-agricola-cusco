/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import static Controlador.Conversiones.ConvertirCadenaToDouble;
import Modelo.Archivo;
import Modelo.Errores;
import Modelo.Resultado;
import Modelo.TiposCultivo;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author danie
 */
public class controladorTiposCultivo {

    //Creamos los atributos
    private Archivo archivo;
    private FileInputStream flujoEntrada;

    //Creamos el constructor
    public controladorTiposCultivo(Archivo archivo) {
        this.archivo = archivo;
    }

    //Creamos el metodo consultar tipo de cultivo
    public void ConsultarTipoCultivoAnio(String ano) throws Exception {
        try {
            Scanner scan = new Scanner(System.in);
            //Obtenemos el fileInputStream para permitirnos manipular el archivo csv
            flujoEntrada = archivo.getFlujoEntrada();

            byte[] data = flujoEntrada.readAllBytes();

            //Traducimos los bytes del arreglo y los igualamos a una variable string
            String contenido = new String(data, StandardCharsets.UTF_8);

            //Una vez traducidos, los guardamos en un arreglo que separara los indices usando como separador
            //El salto de linea que hara que cada linea sea un indice
            String[] datos = contenido.split("\n");

            datos = Arrays.copyOfRange(datos, 1, datos.length);

            //Arraylist es un tipo de arreglo, pero a diferencia del array normal, este no necesita que le 
            //declares su longitud, sino que puedes ir añadiendo datos dentro del arraylist sin problemas
            //
            ArrayList<String> tiposCultivo = new ArrayList<>();
            ArrayList<Double> cantidadSembrada = new ArrayList<>();
            for (String i : datos) {

                String[] registros = i.split(";");

                //"index of" busca un valor en registros[5] dentro del arraylist tiposCultivo 
                //si lo encuentra devuelve el indice del objeto en el arraylist. Si no lo encuentra
                //te devuelve -1, y si no lo encuentra lo agrega al arraylist. Y si encuentra el valor en
                //registros [5] no lo agrega. Al final, nos quedamos con el arraylist que tiene los valores
                //sin repetirse
                String cultivo = registros[5];

                //Guardamos la siembra hecha para esa línea que se está
                //leyendo
                double cantidad = ConvertirCadenaToDouble(registros[7]);

                //Este if es para que no se repita. Se lee "si cultivo
                //no está dentro de tiposCultivo, añadelo al arraylist
                //tiposCultivo
                int index = tiposCultivo.indexOf(cultivo);
                if (index == -1) {
                    tiposCultivo.add(cultivo);
                    cantidadSembrada.add(cantidad);
                } else {
                    cantidadSembrada.set(index, cantidadSembrada.get(index) + cantidad);
                }

            }

            //Si luego de esto, la longitud (size) del arraylist es cero entonces no hubo datos que agregar
            //entonces no se encontro informacion. Pero, si el size del arraylist es mayor a cero, si se encontro
            //informacion, entonces imprimimos esos valores.
            if (tiposCultivo.size() > 0) {
                // Se encontro informacion
                TiposCultivo tc = new TiposCultivo(ano, tiposCultivo.toArray(new String[tiposCultivo.size()]), cantidadSembrada.toArray(new Double[cantidadSembrada.size()]));
                System.out.println("===============Resultados===============");
                System.out.printf("%-30s %-30s\n", "Tipo de cultivo", "Total de siembra (hectáreas)");
                System.out.println("-----------------------------------------------------------");
                for (int i = 0; i < tiposCultivo.size(); i++) {
                    System.out.printf("%-30s %-30s\n", tc.getCultivos()[i], tc.getCantidadSembrada()[i]);
                }

                System.out.println("Le gustaria guardar los resultados en un archivo txt? (S/N) :");
                String opcion = scan.nextLine();
                boolean validacion = true;
                while (validacion == true) {
                    if (opcion.toUpperCase().equals("S")) {
                        Resultado result = new Resultado(3, "Cantidad de siembra por tipos de cultivos", tc.toString());
                        controladorResultado.guardarResultado(result);
                        System.out.println("Datos guardados correctamente en un txt.");
                        validacion = false;
                    } else if (opcion.toUpperCase().equals("N")) {
                        validacion = false;
                    } else {
                        System.out.println("Opcion ingresada no permitida. ");
                        validacion = true;
                    }

                }

            } else {
                // No se encontro informacion
                System.out.println("No se encontro informacion correspondiente al anio introducido.");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Errores error = new Errores(e.getMessage(), "Error",
                    LocalDate.now().toString(), LocalTime.now().toString(), "Usuario");
            controladorErrores.guardarError(error);
            throw e;
        }
    }
}
