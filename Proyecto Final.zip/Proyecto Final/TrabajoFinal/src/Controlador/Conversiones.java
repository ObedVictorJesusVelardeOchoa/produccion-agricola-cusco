/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Errores;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author danie
 */
public class Conversiones {

    //El metodo personalizado para convertir a entero, en caso no sea un entero, se iguala a cero para que no afecte 
    //el proceso de acumulado de siembraTotal. El comando ParseInt va a convertir esa cadena que es String en un entero
    //Al igualar el numero(que es entero) con la cadena convertida, si la cadena efectivamente se podia convertir en un
    //entero, el numero retornado sera ese numero convertido que se acumulara en siembraTotal. Pero, si no era 
    //realmente un entero, se convertira en cero para que al retornar no afecte a la suma de siembraTotal
    public static int ConvertirCadenaToEntero(String cadena) throws Exception {
        int numero = 0;
        try {
            numero = Integer.parseInt(cadena);
        } catch (Exception e) {
            numero = 0;
            Errores error = new Errores(e.getMessage(), "Error",
                    LocalDate.now().toString(), LocalTime.now().toString(), "Usuario");
            controladorErrores.guardarError(error);
        }
        return numero;
    }

    public static double ConvertirCadenaToDouble(String cadena) throws Exception {
        double numero = 0;
        try {
            numero = Double.parseDouble(cadena);
        } catch (Exception e) {
            numero = 0;
            Errores error = new Errores(e.getMessage(), "Error",
                    LocalDate.now().toString(), LocalTime.now().toString(), "Usuario");
            controladorErrores.guardarError(error);
        }
        return numero;
    }
}
