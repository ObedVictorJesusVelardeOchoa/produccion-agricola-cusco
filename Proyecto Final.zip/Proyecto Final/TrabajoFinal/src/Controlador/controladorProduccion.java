/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Archivo;
import Modelo.Errores;
import Modelo.Produccion;
import Modelo.Resultado;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author danie
 */
public class controladorProduccion {

    private Archivo archivo;
    private FileInputStream flujoEntrada;

    public controladorProduccion(Archivo archivo) {
        this.archivo = archivo;
    }

    public void ConsultarProduccionTotalAnio(String ano) throws Exception {

        try {
            Scanner scan = new Scanner(System.in);
            //Obtenemos el fileInputStream
            flujoEntrada = archivo.getFlujoEntrada();

            //Ahora si vamos a empezar a modificar el archivo
            //Primero leemos todos los bytes del archivo y los guardamos en un arreglo de bytes
            byte[] arreglo = flujoEntrada.readAllBytes();

            //Ahora los traducimos e igualamos a una variable de texto
            String contenido = new String(arreglo, StandardCharsets.UTF_8);

            //Ahora esa variable que tiene todas esas lineas vamos a convertir esas lineas en indices de un arreglo
            String[] datos = contenido.split("\n");

            //Eliminamos la primera linea que no nos interesa
            datos = Arrays.copyOfRange(datos, 1, datos.length);

            double produccionTotal = 0;
            for (String i : datos) {
                //Necesitamos que el ayudante que recorrera las lineas "i" separe cada dato en la linea y que el separador sea
                //la ; y que cada dato separado de la linea en la que se encuentre en esa iteracion sea un indice del arreglo
                //datos. Esa es la mision que le vamos a dar al ayudante que recorre las lineas.
                String[] registros = i.split(";");

                //Año es string porque todo lo que esta dentro del csv es String
                if (ano.equalsIgnoreCase(registros[4])) {
                    String numero = registros[10];
                    produccionTotal += Conversiones.ConvertirCadenaToDouble(numero);
                }

            }

            if (produccionTotal > 0) {
                Produccion produccion = new Produccion(ano, produccionTotal);
                System.out.println("===============RESULTADO=================");
                System.out.printf("%-15s %-15s\n", "AnioO", "PRODUCCION TOTAL");
                System.out.println("-----------------------------------------");
                System.out.printf("%-15s %-15.2f\n", produccion.getAno(), produccion.getTotal());

                System.out.println("Le gustaria guardar los resultados en un archivo txt? (S/N) :");
                String opcion = scan.nextLine();
                boolean validacion = true;
                while (validacion == true) {
                    if (opcion.toUpperCase().equals("S")) {
                        Resultado result = new Resultado(2, "Produccion Total por anio", "" + produccion.toString());
                        controladorResultado.guardarResultado(result);
                        System.out.println("Datos guardados correctamente en un txt.");
                        validacion = false;

                    } else if (opcion.toUpperCase().equals("N")) {
                        validacion = false;
                    } else {
                        System.out.println("Opcion ingresada no permitida. ");
                        validacion = true;
                    }

                }

            } else {
                System.out.println("No se encontro informacion correspondiente al anio introducido.");
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            Errores error = new Errores(e.getMessage(), "Error",
                    LocalDate.now().toString(), LocalTime.now().toString(), "Usuario");
            controladorErrores.guardarError(error);
            throw e;
        }

    }

}
