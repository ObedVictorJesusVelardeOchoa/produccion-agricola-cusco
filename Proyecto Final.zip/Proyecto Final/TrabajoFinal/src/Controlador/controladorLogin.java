/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Errores;
import Modelo.Usuario;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

/**
 *
 * @author danie
 */
public class controladorLogin {

    private static final int MAX_INTENTOS = 3;
    private Usuario usuario;
    private int contador = 0;

    public controladorLogin() {
        this.usuario = new Usuario("", "");
    }

    public void ImprimirBienvenidaLogin() {
        System.out.println("********************************************");
        System.out.println("Bienvenido al sistema de analisis de datos");
        System.out.println("********************************************");
    }

    public boolean accesoSistema() throws Exception {
        boolean validado = false;

        Scanner lector = new Scanner(System.in);

        while (contador <= MAX_INTENTOS) {
            System.out.print("Ingresa usuario:");
            usuario.setNombreUsuario(lector.nextLine());

            System.out.print("Ingresa la clave:");
            usuario.setClave(lector.nextLine());

            if (validarUsuario()) {
                // Si las credenciales son válidas, se notifica al usuario y se termina el proceso
                System.out.println("Usuario validado correctamente");
                System.out.println("********************************************");
                validado = true;
                break;
            } else {
                // Si las credenciales no son válidas, se incrementa el contador y se notifica al usuario
                contador++;
                System.out.println("Usuario no validado");
                System.out.println("********************************************");
            }
        }

        return validado;
    }

    public boolean validarUsuario() throws Exception {
        String nombreArchivo = "usuarios.txt";
        File file = new File(nombreArchivo);
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes[0].equals("Usuario:" + usuario.getNombreUsuario())
                        && partes[1].equals("Clave:" + usuario.getClave())) {
                    // Si las credenciales coinciden, devolver true
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            System.err.println("Error al leer la entrada del usuario: " + e.getMessage());
            Errores error = new Errores(e.getMessage(), "Error",
                    LocalDate.now().toString(), LocalTime.now().toString(), "Usuario");
            controladorErrores.guardarError(error);
            return false;

        }
    }
}
