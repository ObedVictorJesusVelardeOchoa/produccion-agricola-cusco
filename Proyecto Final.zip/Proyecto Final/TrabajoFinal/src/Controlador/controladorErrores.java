/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.io.IOException;
import java.io.FileWriter;
import Modelo.Errores;
import java.io.File;

/**
 *
 * @author elcev
 */
public class controladorErrores {

    public static void guardarError(Errores error) throws Exception {
        // Nombre del archivo
        String nombreArchivo = "errores.log";

        // Texto que se va a escribir en el archivo
        String texto = error.toString();
        // Crear el archivo
        File archivo = new File(nombreArchivo);

        // Utilizar FileWriter para escribir en el archivo
        try (FileWriter escritor = new FileWriter(archivo, true)) {
            escritor.write(texto + System.lineSeparator());
        } catch (IOException e) {
            // Manejar la excepción en caso de error
            System.err.println("Error al escribir en el archivo: " + e.getMessage());
            throw e;
        }
    }
}
