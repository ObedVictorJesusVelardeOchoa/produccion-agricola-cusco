/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Resultado;
import java.io.File;
import java.io.FileWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author danie
 */
public class controladorResultado {

    public static void guardarResultado(Resultado result) {  //parametros         
        DateTimeFormatter formatFecha = DateTimeFormatter.ofPattern("yyyy_MM_dd_HH_mm_ss");  //Definimos el formato de fecha y hora
        String fecha = formatFecha.format(LocalDateTime.now());

        String nombreArchivo = fecha + "_Resultados.txt";   //El nombre y tipo (.txt) del archivo que se va a crear

        File archivo = new File(nombreArchivo); //Crea y cuando está creado accede al archivo

        try (FileWriter escritor = new FileWriter(archivo, true)) {  //FileWriter escribe dentro del archivo
            escritor.write(result.toString()); //Escribimos dentro del archivo el resultado
        } catch (Exception e) {
            System.err.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }
}
