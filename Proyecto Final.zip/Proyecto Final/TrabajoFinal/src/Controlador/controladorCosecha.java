/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Archivo;
import Modelo.Cosecha;
import Modelo.Errores;
import Modelo.Resultado;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

/**
 *
 * @author danie
 */
public class controladorCosecha {

    private Archivo archivo;
    private FileInputStream flujoEntrada;

    //Creamos el constructor donde solo le pasaremos la ruta para instanciar posteriormente la clase controladorCosecha
    public controladorCosecha(Archivo archivo) {
        this.archivo = archivo;
    }

    public void ConsultarCosechTotalAnio(String ano) throws Exception { //Basandonos en un ejemplo del profesor, Declaramos el throws Exception para comprobar la exception en el catch (throw e)

        try {
            Scanner scan = new Scanner(System.in);
            //Obtenemos el fileInputStream
            flujoEntrada = archivo.getFlujoEntrada();
            //Leemos los bytes de archivo y los guardamos en un arreglo de bytes
            byte[] bytes = flujoEntrada.readAllBytes();
            //Traducimos los bytes y los guardamos en una variable String

            String datos = new String(bytes, StandardCharsets.UTF_8);

            String[] contenido = datos.split("\n");

            double cosechaTotal = 0;
            for (String i : contenido) {
                String[] registros = i.split(";");

                if (ano.equalsIgnoreCase(registros[4])) {
                    String numero = registros[8];
                    cosechaTotal += Conversiones.ConvertirCadenaToDouble(numero);
                }

            }

            if (cosechaTotal > 0) {
                Cosecha cosecha = new Cosecha(ano, cosechaTotal);
                System.out.println("===============RESULTADO=================");
                System.out.printf("%-15s %-15s\n", "ANIO", "COSECHA TOTAL");
                System.out.println("-----------------------------------------");
                System.out.printf("%-15s %-15.2f\n", cosecha.getAno(), cosecha.getTotal());

                System.out.println("Le gustaria guardar los resultados en un archivo txt? (S/N) :");
                String opcion = scan.nextLine();
                boolean validacion = true;
                while (validacion == true) {
                    if (opcion.toUpperCase().equals("S")) {
                        Resultado result = new Resultado(4, //Numero de ejercicio
                                "Cosecha en un anio determinado", //
                                cosecha.toString());
                        controladorResultado.guardarResultado(result);
                        System.out.println("Datos guardados correctamente en un txt.");
                        validacion = false;

                    } else if (opcion.toUpperCase().equals("N")) {
                        validacion = false;
                    } else {
                        System.out.println("Opcion ingresada no permitida. ");
                        validacion = true;
                    }

                }

            } else {
                System.out.println("No se encontro informacion respecto al anio dado.");
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            Errores error = new Errores(e.getMessage(), "Error",
                    LocalDate.now().toString(), LocalTime.now().toString(), "Usuario");
            controladorErrores.guardarError(error);
            throw e;  //invocamos el throw y llamamos a la excepcion. Esta linea Hace que se muestre la excepcion completa en consola
        }

    }

}
