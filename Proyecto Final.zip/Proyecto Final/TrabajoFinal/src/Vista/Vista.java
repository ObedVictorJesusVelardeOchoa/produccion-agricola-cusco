package Vista;

import Controlador.controladorCosecha;
import Controlador.controladorLogin;
import Controlador.controladorProduccion;
import Controlador.controladorSiembra;
import Controlador.controladorTiposCultivo;
import Modelo.Archivo;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author danie
 */
public class Vista {

    //Para poder instanciar la vista posteriormente en el metodo Main, debemos crear este constructor
    public Vista() {
    }

    Scanner scan = new Scanner(System.in);

    public boolean IniciarSession() throws Exception {
        boolean condicion = false;

        controladorLogin cl = new controladorLogin();
        cl.ImprimirBienvenidaLogin();

        condicion = cl.accesoSistema();

        return condicion;
    }

    public boolean MostrarMenu(String ruta) throws Exception {

        boolean resultado = false;

        // Instanciamos un objeto de la clase Archivo
        Archivo file = new Archivo(ruta);
        // abrimos por única vez el archivo
        file.abrirArchivo();

        while (resultado == false) {
            System.out.println("""
          Bienvenido al consultador de datos de la Producion Agricola de la Region del Cuzco (2018-2020)
          Por favor, ingrese una de las siguientes opciones: 
                           1.- Consultar datos de Siembras
                           2.- Consultar datos de Produccion
                           3.- Consultar tipos de Cultivo Sembrados
                           4.- Consultar total de Cosecha
                           0.- Salir
                           """);
            int opcion = scan.nextInt();
            scan.nextLine();

            switch (opcion) {
                case 0:
                    file.cerrarArchivo();
                    System.out.println("GRACIAS, NOS VEMOS PRONTO.");
                    System.exit(0);
                    break;
                case 1:
                    System.out.println("Primero, ingrese la provincia deseada: ");
                    String provincia = scan.nextLine();
                    System.out.println("Ahora ingrese el distrito deseado: ");
                    String distrito = scan.nextLine();
                    controladorSiembra c = new controladorSiembra(file);
                    c.ConsultarSiembrasTotalesProvinciaDistrito(provincia, distrito);
                    break;
                case 2:
                    System.out.println("Ingrese el anio que deseado: ");
                    String anio = scan.nextLine();
                    controladorProduccion p = new controladorProduccion(file);
                    p.ConsultarProduccionTotalAnio(anio);
                    break;
                case 3:
                    System.out.println("Ingrese el anio deseado: ");
                    String ano = scan.nextLine();
                    controladorTiposCultivo cultivo = new controladorTiposCultivo(file);
                    cultivo.ConsultarTipoCultivoAnio(ano);
                    break;
                case 4:
                    System.out.println("Ingrese el anio deseado: ");
                    String aniod = scan.nextLine();
                    controladorCosecha cosecha = new controladorCosecha(file);
                    cosecha.ConsultarCosechTotalAnio(aniod);
                    break;
                default:
                    file.cerrarArchivo();
                    MostrarMenu(ruta);
            }

            System.out.println("¿Desea realizar otra operación? (S/N)");
            String operacion = scan.nextLine();

            if (operacion.equalsIgnoreCase("s")) {
                resultado = false;
                file.abrirArchivo();
            } else {
                //Cerramos el archiv
                file.cerrarArchivo();
                resultado = true;
            }
        }

        return resultado;
    }

}
