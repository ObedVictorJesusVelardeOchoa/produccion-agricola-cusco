/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Vista;

/**
 *
 * @author carlospalominovidal
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {  //Cuando ocurre una excepcion, el throws para y devuelve la excepcion
        // TODO code application logic here
        String ruta = "Produccion_Agricola_Region_Cusco_2018-2020.csv";
        Vista v = new Vista();
        boolean inicioSession = v.IniciarSession();

        if (inicioSession == true) {
            boolean resultado = v.MostrarMenu(ruta);

            if (resultado) {
                System.exit(0);
            }
        }

    }

}
